import 'package:flutter/material.dart';
import 'package:project_flca2/src/core/router/router.dart';

void main() {
  runApp(const RouterWidget());
}

class RouterWidget extends StatelessWidget {
  const new({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      routerConfig: router,
      title: "Meu App"
    );
  }
}