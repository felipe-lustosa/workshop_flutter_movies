import 'package:flutter/material.dart';

class FormPage extends StatefulWidget {
  const new({super.key});

  @override
  State<FormPage> createState() => _FormPageState();
}

class _FormPageState extends State<FormPage> {
  final _controllerName = TextEditingController(text: '');
  final _controllerEmail = TextEditingController(text: '');
  final _controllerAddress = TextEditingController(text: '');
  var textScreen = {
    "name": "",
    "email": "",
    "address": ""
  };

  void resetControllers() {
    _controllerName.clear();
    _controllerEmail.clear();
    _controllerAddress.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.pinkAccent,
        title: Text('Formulário')
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          spacing: 16,
          children: [
            TextField(
              controller: _controllerName, 
              decoration: InputDecoration(border: OutlineInputBorder(), label: Text("Name"), ), 
            ),
            TextField(
              controller: _controllerEmail, 
              decoration: InputDecoration(border: OutlineInputBorder(), label: Text("E-mail")), 
            ),
            TextField(
              controller: _controllerAddress, 
              decoration: InputDecoration(border: OutlineInputBorder(), label: Text("Endereço")), 
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              spacing: 16,
              children: [
                OutlinedButton(onPressed: () => {
                  setState(() {
                    resetControllers();
                  })
                }, child: Text("Cancel")),
                ElevatedButton(onPressed: () => {
                  setState(() {
                    textScreen["name"] = _controllerName.text;
                    textScreen["email"] = _controllerEmail.text;
                    textScreen["address"] = _controllerAddress.text;
                    resetControllers();
                  })
                }, child: Text("Confirm")),
              ],
            ),
            Container(
              width: double.maxFinite,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.black),
                borderRadius: BorderRadius.circular(10)
              ),
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  spacing: 8,
                  children: [
                    Text("Dados"),
                    Row(
                      children: [
                        Text("Nome: "),
                        Text(textScreen["name"].toString(), style: TextStyle(fontWeight: FontWeight.bold)),
                      ]
                    ),
                    Row(
                      children: [
                        Text("E-mail: "),
                        Text(textScreen["email"].toString(), style: TextStyle(fontWeight: FontWeight.bold)),
                      ]
                    ),
                    Row(
                      children: [
                        Text("Address: "),
                        Text(textScreen["address"].toString(), style: TextStyle(fontWeight: FontWeight.bold)),
                      ]
                    ),
                  ],
                ),
              ),
            )
          ]
        ),
      ),
    );
  }
}